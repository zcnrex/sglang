import json,torch,sys
from lossless import pack,unpack
for name,x in [
 ('all16bitpatterns',torch.arange(65536,device='cuda',dtype=torch.int32).to(torch.int16).view(torch.bfloat16).reshape(-1,128)),
 ('random16bitpatterns',torch.randint(-32768,32768,(4096,128),device='cuda',dtype=torch.int16).view(torch.bfloat16)),
 ('normal',torch.randn(8192,128,device='cuda').bfloat16()),
 ('zeros',torch.zeros(3,128,device='cuda',dtype=torch.bfloat16)),
 ('signedzeros',torch.full((3,128),-32768,device='cuda',dtype=torch.int16).view(torch.bfloat16))]:
 p,m=pack(x);y=unpack(p,m);assert torch.equal(x.view(torch.int16),y.view(torch.int16)),name
 hit=((m.to(torch.int32)&256)!=0).float().mean().item()
 print(json.dumps(dict(case=name,rows=x.shape[0],bitwise=True,compressed_fraction=hit,expected_read_bytes_per_row=258-64*hit)),flush=True)
