import torch,triton,json,statistics,gc
from lossless import pack,unpack,read_kernel
n=1<<24
torch.manual_seed(123)
x=torch.randn((n,128),device='cuda',dtype=torch.float32).bfloat16()
p,m=pack(x)
y=unpack(p,m);assert torch.equal(x.view(torch.int16),y.view(torch.int16));del y
print("4GiB bitwise unpack passed",flush=True)
hit=((m.to(torch.int32)&256)!=0).float().mean().item()
o=torch.empty(n,device='cuda',dtype=torch.float32)
print(json.dumps(dict(rows=n,raw_bytes=x.numel()*2,allocated_payload_bytes=p.numel(),metadata_bytes=m.numel()*2,compressed_fraction=hit,logical_read_bytes=n*(258-64*hit))),flush=True)
for rows,warps in [(16,4),(32,4),(64,8),(128,8)]:
 graphs={};samples={False:[],True:[]}
 for packed in [False,True]:
  def f():read_kernel[(triton.cdiv(n,rows),)](x.view(torch.int16),p,m,o,n,rows,packed,num_warps=warps)
  f();g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g):f()
  graphs[packed]=g
  if not packed:ref=o.clone()
  else:
   max_sum_diff=(o-ref).abs().max().item()
   torch.testing.assert_close(o,ref,rtol=1e-5,atol=1e-5)
 for rep in range(6):
  for packed in ([False,True] if rep%2==0 else [True,False]):
   g=graphs[packed]
   for _ in range(3):g.replay()
   a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
   for _ in range(5):g.replay()
   b.record();b.synchronize();samples[packed].append(a.elapsed_time(b)/5)
 print(json.dumps(dict(rows_per_cta=rows,warps=warps,raw_median_ms=statistics.median(samples[False]),packed_median_ms=statistics.median(samples[True]),raw_samples_ms=samples[False],packed_samples_ms=samples[True],max_row_sum_diff=max_sum_diff,cache_bits_exact=True)),flush=True)
 del graphs,g,ref;gc.collect()
