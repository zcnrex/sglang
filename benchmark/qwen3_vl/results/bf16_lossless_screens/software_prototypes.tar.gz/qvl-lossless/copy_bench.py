import torch,triton,json,statistics,gc,pathlib
from lossless import pack,unpack,copy_kernel
for path in sorted(pathlib.Path('/root/qvl/experiments/real-kv-capture').glob('layer*_*.pt')):
 x=torch.load(path,map_location='cuda',weights_only=True).contiguous();p,m=pack(x);y=unpack(p,m)
 assert torch.equal(x.view(torch.int16).reshape(-1,128),y.view(torch.int16))
 print(json.dumps(dict(case=path.name,rows=m.numel(),compressed_fraction=((m.to(torch.int32)&256)!=0).float().mean().item(),bitwise=True)),flush=True)
 del x,p,m,y;gc.collect()
n=1<<24;torch.manual_seed(123);x=torch.randn(n,128,device='cuda').bfloat16();p,m=pack(x);o=torch.empty_like(x)
hit=((m.to(torch.int32)&256)!=0).float().mean().item()
for rows,warps in [(32,4),(128,8)]:
 graphs={};samples={False:[],True:[]}
 for packed in [False,True]:
  def f():copy_kernel[(triton.cdiv(n,rows),)](x.view(torch.int16),p,m,o.view(torch.int16),n,rows,packed,num_warps=warps)
  f();assert torch.equal(o.view(torch.int16),x.view(torch.int16));g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g):f()
  graphs[packed]=g
 for rep in range(6):
  for packed in ([False,True] if rep%2==0 else [True,False]):
   g=graphs[packed]
   for _ in range(3):g.replay()
   a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
   for _ in range(5):g.replay()
   b.record();b.synchronize();samples[packed].append(a.elapsed_time(b)/5)
 print(json.dumps(dict(rows_per_cta=rows,warps=warps,raw_median_ms=statistics.median(samples[False]),unpack_median_ms=statistics.median(samples[True]),raw_read_bytes=n*256,packed_logical_read_bytes=n*(258-64*hit),write_bytes=n*256,compressed_fraction=hit,bitwise=True)),flush=True)
 del graphs,g;gc.collect()
