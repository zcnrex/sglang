import json,time,statistics,gc
import torch,flashinfer
from cuda.bindings import driver as d
from sglang.srt.utils.cuda_vmm_utils import *
torch.cuda.set_device(0);torch.manual_seed(20261007)
B,L,H,D,P=128,8192,8,128,32
shape=(B*L//P,H,P,D);nbytes=B*L*H*D*2
props=[]
caches={}
for pad in [0,128,512,4096]:
 stride=(H*P*D+pad,P*D,D,1)
 caches[str(pad)]=tuple(torch.empty_strided(shape,stride,device='cuda',dtype=torch.bfloat16) for _ in range(2))
 props.append(dict(padding_elements=pad,stride=stride,capacity_overhead=pad/(H*P*D)))
q=torch.randn(B,32,D,device='cuda',dtype=torch.bfloat16)
ws=torch.empty(512*1024**2,device='cuda',dtype=torch.uint8)
table=torch.arange(B*L//P,device='cuda',dtype=torch.int32).reshape(B,L//P)
lens=torch.full((B,),L,device='cuda',dtype=torch.int32)
outs={k:torch.empty_like(q) for k in caches}
def call(k):
 return flashinfer.decode.trtllm_batch_decode_with_kv_cache(query=q,kv_cache=caches[k],workspace_buffer=ws,block_tables=table,seq_lens=lens,max_seq_len=L,bmm1_scale=D**-.5,bmm2_scale=1.,out=outs[k])
report=dict(shape=shape,allocations=props,torch=torch.__version__,flashinfer=flashinfer.__version__,device=torch.cuda.get_device_name(),cases={})
for case in ['gaussian']:
 for i,kv in enumerate('kv'):
  if case=='gaussian':src=torch.randn(shape,device='cuda',dtype=torch.float32).bfloat16()
  elif case=='zero':src=torch.zeros(shape,device='cuda',dtype=torch.bfloat16)
  else:
   x=torch.load('/root/qvl/experiments/real-kv-capture/layer'+case[4:]+'_'+kv+'.pt',map_location='cuda',weights_only=True)
   src=x.reshape(L//P,P,H,D).permute(0,2,1,3).contiguous().repeat(B,1,1,1)
  for cache in caches.values():cache[i].copy_(src)
  assert all(torch.equal(cache[i].view(torch.int16),src.view(torch.int16)) for cache in caches.values())
  del src
 graphs={}
 for k in caches:
  call(k);torch.cuda.synchronize();g=torch.cuda.CUDAGraph()
  with torch.cuda.graph(g):
   for _ in range(10):call(k)
  graphs[k]=g
 assert all(torch.equal(outs[k],outs['0']) for k in caches)
 timings={k:[] for k in caches}
 for rep in range(10):
  for k in list(caches)[::1 if rep%2==0 else -1]:
   g=graphs[k]
   for _ in range(3):g.replay()
   a,z=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
   a.record()
   for _ in range(10):g.replay()
   z.record();z.synchronize();timings[k].append(a.elapsed_time(z)*10)
 result=dict(bitwise_cache=True,bitwise_output=True,us=timings,median_us={k:statistics.median(v) for k,v in timings.items()})
 report['cases'][case]=result
 print(case,json.dumps(result),flush=True)
 with open('/root/qvl/experiments/page-padding/report.json','w') as f:json.dump(report,f,indent=2)
 del graphs;gc.collect()
# Non-owning tensors and graphs must die before mappings. Process exit handles teardown.
