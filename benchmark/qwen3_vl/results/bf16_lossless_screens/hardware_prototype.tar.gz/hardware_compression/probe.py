import torch
from cuda.bindings import driver as d
from sglang.srt.utils.cuda_vmm_utils import *
torch.cuda.init()
p=make_device_allocation_prop(0,handle_types=None)
p.allocFlags.compressionType=1
g=check_drv(d.cuMemGetAllocationGranularity(p,d.CUmemAllocationGranularity_flags.CU_MEM_ALLOC_GRANULARITY_MINIMUM),'granularity')
r=VmmReservation(g,p,0)
h=r.map(0,g,retain_handle=True)
print('handle',h,'granularity',g,flush=True)
a=check_drv(d.cuMemGetAllocationPropertiesFromHandle(h),'properties')
print('requested',p.allocFlags.compressionType,'actual',a.allocFlags.compressionType,flush=True)
r.close()
