import json,torch
from pathlib import Path
from sglang.kernels.jit.utils import load_jit
from sglang.kernels.ops.layernorm.norm import fused_inplace_qknorm
from sglang.kernels.ops.attention.rotary_triton import triton_mrope_fused
from triton.testing import do_bench_cudagraph
root=Path(__file__).parent
base=(root/'base.cuh').read_text()
mods={}
for warps in (4,8,16):
 for static in (False,True):
  name=f'w{warps}_s{int(static)}'
  text=base.replace('blockIdx.x * 4 +','blockIdx.x * '+str(warps)+' +').replace('p.tokens, 4u), 128,','p.tokens, '+str(warps)+'u), '+str(warps*32)+',')
  if static:
   text=text.replace('(p.q_heads + p.k_heads)','40u').replace('head < p.q_heads','head < 32u').replace('head - p.q_heads','head - 32u')
  path=root/(name+'.cuh');path.write_text(text)
  mods[name]=load_jit('qvl_norm_'+name,cuda_files=[str(path)],cuda_wrappers=[('run','FusedQKNormMRoPE<true>::run')])
for n in (128,8192,16384):
 torch.manual_seed(42)
 x=torch.randn(n,6144,device='cuda',dtype=torch.bfloat16);orig=x.clone();q=x[:,:4096];k=x[:,4096:5120]
 qw=torch.randn(128,device='cuda',dtype=torch.bfloat16);kw=torch.randn_like(qw)
 phase=torch.randn(16384,64,device='cuda');cache=torch.cat([phase.cos(),phase.sin()],1).bfloat16();p=torch.randint(0,16384,(3,n),device='cuda');axes=torch.tensor([0]*24+[1]*20+[2]*20,device='cuda',dtype=torch.int64)
 def ref():
  fused_inplace_qknorm(q.view(n,32,128),k.view(n,8,128),qw,kw,head_dim=128,eps=1e-6)
  triton_mrope_fused(q,k,cache,p,[24,20,20],128,128,False,False,True,None)
 ref();expected=x.clone()
 timings={};correct={}
 for name,mod in mods.items():
  x.copy_(orig);mod.run(q,k,qw,kw,cache,p,axes,1e-6)
  correct[name]=torch.equal(x,expected)
  assert correct[name],(n,name,(x-expected).abs().max().item())
  x.copy_(orig);timings[name]=1000*do_bench_cudagraph(lambda:mod.run(q,k,qw,kw,cache,p,axes,1e-6),rep=1000)
 x.copy_(orig);timings['unfused']=1000*do_bench_cudagraph(ref,rep=1000)
 print(json.dumps(dict(n=n,correct=correct,us=timings)),flush=True)
