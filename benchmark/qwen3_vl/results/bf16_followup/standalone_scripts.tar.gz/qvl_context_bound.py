import torch,flashinfer,json,gc,statistics
for n in [8192,9216]:
 for prefix,qlen,tail in [(1,8192,0),(2,8192,0),(2,4096,128)]:
  bs=prefix+tail;p=32;d=128;torch.manual_seed(123)
  q=torch.randn(prefix*qlen+tail,32,d,device='cuda',dtype=torch.bfloat16)
  k=torch.randn(bs*n//p,8,p,d,device='cuda',dtype=q.dtype);v=torch.randn_like(k)
  table=torch.arange(bs*n//p,device='cuda',dtype=torch.int32).reshape(bs,-1);lens=torch.full((bs,),n,device='cuda',dtype=torch.int32)
  cuq=torch.arange(prefix+1,device='cuda',dtype=torch.int32)*qlen;cuk=torch.arange(prefix+1,device='cuda',dtype=torch.int32)*n
  ws=torch.empty(512*1024*1024,device='cuda',dtype=torch.uint8);out=torch.empty_like(q)
  def f(bound):
   flashinfer.prefill.trtllm_batch_context_with_kv_cache(query=q[:prefix*qlen],kv_cache=(k,v),workspace_buffer=ws,block_tables=table[:prefix],seq_lens=lens[:prefix],max_q_len=qlen,max_kv_len=bound,bmm1_scale=d**-.5,bmm2_scale=1.,batch_size=prefix,cum_seq_lens_q=cuq,cum_seq_lens_kv=cuk,out=out[:prefix*qlen])
   if tail:flashinfer.decode.trtllm_batch_decode_with_kv_cache(query=q[prefix*qlen:],kv_cache=(k,v),workspace_buffer=ws,block_tables=table[prefix:],seq_lens=lens[prefix:],max_seq_len=262144,bmm1_scale=d**-.5,bmm2_scale=1.,out=out[prefix*qlen:])
  f(262144);ref=out.clone();graphs={};diffs={};samples={n:[],262144:[]}
  for bound in [n,262144]:
   f(bound);diffs[bound]=(out.float()-ref.float()).abs().max().item();g=torch.cuda.CUDAGraph()
   with torch.cuda.graph(g):
    for _ in range(5):f(bound)
   graphs[bound]=g
  for rep in range(6):
   for bound in ([n,262144] if rep%2==0 else [262144,n]):
    g=graphs[bound]
    for _ in range(3):g.replay()
    a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
    for _ in range(10):g.replay()
    b.record();b.synchronize();samples[bound].append(a.elapsed_time(b)*20)
  for bound in samples:print(json.dumps(dict(n=n,prefix=prefix,qlen=qlen,decode_tail=tail,bound=bound,median_us=statistics.median(samples[bound]),samples_us=samples[bound],maxdiff=diffs[bound])),flush=True)
  del graphs,g,q,k,v,table,lens,cuq,cuk,ws,out,ref;gc.collect();torch.cuda.empty_cache()
