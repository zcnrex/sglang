import requests,random,time,json,pathlib,concurrent.futures
D=pathlib.Path('/root/qvl/experiments/bf16-scheduler-new/profile');url='http://127.0.0.1:32000'
for _ in range(180):
 try:
  if requests.get(url+'/v1/models').ok:break
 except requests.RequestException:pass
 time.sleep(2)
else:raise RuntimeError('not ready')
(D/'server_info.json').write_text(requests.get(url+'/server_info').text)
def run(bs,out=128):
 requests.post(url+'/flush_cache').raise_for_status()
 r=random.Random(42+bs);ids=[[r.randrange(1000,30000) for _ in range(8192)] for i in range(bs)]
 t=time.monotonic();ans=requests.post(url+'/generate',json={'input_ids':ids,'sampling_params':{'temperature':0,'max_new_tokens':out,'ignore_eos':True}},timeout=300);ans.raise_for_status();elapsed=time.monotonic()-t
 (D/f'response-bs{bs}.json').write_text(ans.text)
 print(json.dumps(dict(bs=bs,output_len=out,elapsed=elapsed)),flush=True)
run(1,128)
for bs in (1,128):
 out=D/f'lowoverhead-bs{bs}';out.mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(1) as pool:
  f=pool.submit(requests.post,url+'/start_profile',json={'output_dir':str(out),'num_steps':20,'activities':['CPU','GPU'],'with_stack':False,'record_shapes':False,'profile_by_stage':True,'profile_prefix':f'bs{bs}'},timeout=300)
  time.sleep(.3)
  run(bs,128)
  print(f.result().text,flush=True)
