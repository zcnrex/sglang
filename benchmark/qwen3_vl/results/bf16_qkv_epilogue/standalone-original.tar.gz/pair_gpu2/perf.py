import torch,json,pathlib,glob,os,hashlib,statistics
from safetensors import safe_open
import prototype
from flashinfer.gemm.kernels.dense_bf16_gemm_sm100_splitk import run_splitk_dense,SplitKTactic
from sglang.kernels.ops.attention.fused_qk_norm_mrope import fused_qk_norm_mrope
root=pathlib.Path(__file__).parent
torch.manual_seed(9107);torch.backends.cuda.matmul.allow_tf32=False
model='/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17'
d={}
for p in glob.glob(model+'/*.safetensors'):
 with safe_open(p,framework='pt',device='cpu') as f:
  for key in f.keys():
   if '.self_attn.' in key and any(key.endswith(x+'.weight') for x in ['q_proj','k_proj','v_proj','q_norm','k_norm']):d[key]=f.get_tensor(key).cuda().bfloat16()
phase=torch.arange(8400,device='cuda')[:,None].float()*torch.arange(1,65,device='cuda')[None,:].float()*.0001
rope=torch.cat([phase.cos(),phase.sin()],1).bfloat16();pos=torch.arange(8200,8208,device='cuda',dtype=torch.int64)[None,:].expand(3,-1).clone();axes=torch.tensor([0]*24+[1]*20+[2]*20,device='cuda',dtype=torch.int64)
# Each layer retains disjoint full-length HND caches. All variants write the same valid token slots.
slots=torch.arange(8,device='cuda',dtype=torch.int64)*8256+8200
states=[]
for layer in range(36):
 prefix=f'model.language_model.layers.{layer}.self_attn.'
 w=torch.cat([d[prefix+x+'_proj.weight'] for x in ['q','k','v']]);qw=d[prefix+'q_norm.weight'];kw=d[prefix+'k_norm.weight']
 x=torch.randn(8,2560,device='cuda',dtype=torch.bfloat16);a=torch.empty(8,6144,device='cuda',dtype=torch.bfloat16);b=torch.empty_like(a)
 ka=torch.zeros((2064,8,32,128),device='cuda',dtype=torch.bfloat16);va=torch.zeros_like(ka);kb=torch.zeros_like(ka);vb=torch.zeros_like(ka)
 ep=(qw,kw,rope,pos,axes,kb,vb,slots)
 states.append((x,w,a,b,ka,va,kb,vb,ep))
d.clear();torch.cuda.empty_cache()
f=prototype.compile_epilogue(states[0][0],states[0][1].T,states[0][3],states[0][-1])
print('compile_done',flush=True)
def run(i,v):
 x,w,a,b,ka,va,kb,vb,ep=states[i];qw,kw,rope,pos,axes,kb,vb,slots=ep
 if v=='reference':
  run_splitk_dense(x,w.T,None,a,True,SplitKTactic(128,8,2,6))
  fused_qk_norm_mrope(a[:,:4096],a[:,4096:5120],qw,kw,rope,pos,axes,1e-6,value=a[:,5120:],key_cache=ka.permute(0,2,1,3),value_cache=va.permute(0,2,1,3),slots=slots)
 else:f(x,w.T,b,ep)
checks=[]
def check(tag):
 torch.cuda.synchronize()
 for layer,(x,w,a,b,ka,va,kb,vb,ep) in enumerate(states):
  row=dict(tag=tag,layer=layer)
  for name,u,v in [('qkv',a,b),('keycache',ka,kb),('valuecache',va,vb)]:
   eq=torch.equal(u,v);row[name+'_bitwise']=eq
   if not eq:
    e=u.float()-v.float();row[name+'_max_abs']=e.abs().max().item();row[name+'_nrms']=(e.square().mean()/u.float().square().mean()).sqrt().item()
   assert eq,row
  checks.append(row)
 print(tag,'36_layers_bitwise',flush=True)
for v in ['reference','candidate']:
 for i in range(36):run(i,v)
check('initial')
graphs={}
for v in ['reference','candidate']:
 for _ in range(3):
  for i in range(36):run(i,v)
 torch.cuda.synchronize();g=torch.cuda.CUDAGraph(keep_graph=True)
 with torch.cuda.graph(g):
  for i in range(36):run(i,v)
 graphs[v]=g;g.debug_dump(str(root/(v+'.dot')))
for st in states:st[0].normal_()
pos.add_(13)
for g in graphs.values():g.replay()
check('changed_input_graph')
for g in graphs.values():
 for _ in range(6):g.replay()
torch.cuda.synchronize()
def timing(v):
 a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
 for _ in range(100):graphs[v].replay()
 b.record();b.synchronize();return a.elapsed_time(b)*1000/(100*36)
rounds=[]
for r in range(8):
 row={v:timing(v) for v in (['reference','candidate'] if r%2==0 else ['candidate','reference'])};rounds.append(row);print(json.dumps(row),flush=True)
result=dict(checks=checks,rounds=rounds,median_us={v:statistics.median(x[v] for x in rounds) for v in ['reference','candidate']},weight_bytes=sum(s[1].numel()*2 for s in states),cache_bytes_per_arm=sum(s[4].numel()*4 for s in states),pdl=True,states=36,tactic=[128,8,2,6],text_positions_only=True,prototype_sha256=hashlib.sha256(pathlib.Path(prototype.__file__).read_bytes()).hexdigest())
(root/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['median_us']),flush=True)
