import torch,json,pathlib,glob,os,hashlib
from safetensors import safe_open
import prototype
from flashinfer.gemm.kernels.dense_bf16_gemm_sm100_splitk import run_splitk_dense,SplitKTactic
from sglang.kernels.ops.attention.fused_qk_norm_mrope import fused_qk_norm_mrope
root=pathlib.Path(__file__).parent
torch.manual_seed(9107);torch.backends.cuda.matmul.allow_tf32=False
model='/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17'
d={}
for p in glob.glob(model+'/*.safetensors'):
 with safe_open(p,framework='pt',device='cpu') as f:
  for key in f.keys():
   if '.layers.0.self_attn.' in key and any(key.endswith(x+'.weight') for x in ['q_proj','k_proj','v_proj','q_norm','k_norm']):d[key]=f.get_tensor(key).cuda().bfloat16()
prefix='model.language_model.layers.0.self_attn.'
w=torch.cat([d[prefix+x+'_proj.weight'] for x in ['q','k','v']]);qw=d[prefix+'q_norm.weight'];kw=d[prefix+'k_norm.weight']
x=torch.randn(8,2560,device='cuda',dtype=torch.bfloat16);a=torch.empty(8,6144,device='cuda',dtype=torch.bfloat16);b=torch.empty_like(a)
phase=torch.arange(8400,device='cuda')[:,None].float()*torch.arange(1,65,device='cuda')[None,:].float()*.0001
rope=torch.cat([phase.cos(),phase.sin()],1).bfloat16();pos=torch.arange(8200,8208,device='cuda',dtype=torch.int64)[None,:].expand(3,-1).clone();axes=torch.tensor([0]*24+[1]*20+[2]*20,device='cuda',dtype=torch.int64);slots=torch.tensor([65,17,125,-1,39,4,94,120],device='cuda',dtype=torch.int64)
ka=torch.full((4,8,32,128),float('nan'),device='cuda',dtype=torch.bfloat16);va=torch.full_like(ka,float('nan'));kb=torch.full_like(ka,float('nan'));vb=torch.full_like(ka,float('nan'))
ep=(qw,kw,rope,pos,axes,kb,vb,slots)
print('compile_begin',flush=True);f=prototype.compile_epilogue(x,w.T,b,ep);print('compile_done',flush=True)
def ref():
 run_splitk_dense(x,w.T,None,a,True,SplitKTactic(128,8,2,6))
 fused_qk_norm_mrope(a[:,:4096],a[:,4096:5120],qw,kw,rope,pos,axes,1e-6,value=a[:,5120:],key_cache=ka.permute(0,2,1,3),value_cache=va.permute(0,2,1,3),slots=slots)
def cand():f(x,w.T,b,ep)
checks=[]
def check(tag):
 torch.cuda.synchronize();row=dict(tag=tag)
 for name,u,v in [('qkv',a,b),('keycache',ka,kb),('valuecache',va,vb)]:
  finite=torch.isfinite(u);assert torch.equal(finite,torch.isfinite(v));diff=(u[finite].float()-v[finite].float());row[name]=dict(bitwise=torch.equal(u[finite],v[finite]),max_abs=diff.abs().max().item(),nrms=(diff.square().mean()/u[finite].float().square().mean()).sqrt().item());assert row[name]['nrms']<.005
 checks.append(row);print(json.dumps(row),flush=True)
ref();cand();check('initial')
graphs={}
for name,fn in [('ref',ref),('candidate',cand)]:
 for _ in range(3):fn()
 torch.cuda.synchronize();g=torch.cuda.CUDAGraph(keep_graph=True)
 with torch.cuda.graph(g):fn()
 graphs[name]=g;g.debug_dump(str(root/(name+'.dot')))
x.normal_();pos.add_(13)
for g in graphs.values():g.replay()
check('changed_input_graph')
(root/'correctness.json').write_text(json.dumps(dict(checks=checks,text_positions_only=True,prototype_sha256=hashlib.sha256(pathlib.Path(prototype.__file__).read_bytes()).hexdigest()),indent=2))
