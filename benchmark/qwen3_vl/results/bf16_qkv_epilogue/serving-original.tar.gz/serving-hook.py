import os,pathlib,json,copy,hashlib,atexit
import numpy as np
import torch
import prototype
import sglang.benchmark.one_batch as b
import sglang.srt.models.qwen3 as q3
from flashinfer.autotuner import AutoTuner
from sglang.srt.mem_cache.memory_pool import KVWriteLoc,MHATokenToKVPool
from sglang.srt.layers.attention.trtllm_mha_backend import TRTLLMHAAttnBackend
out=pathlib.Path(os.environ['QVL_LMHEAD_OUT']);out.mkdir(exist_ok=True,parents=True)
active=os.environ.get('QVL_LMHEAD_HOOK')=='1';compiled={};prep_seen=set();saved={};report={}
original_prepare=q3.Qwen3Attention.forward_prepare_native

def prepare(self,positions,hidden_states,forward_batch):
 if not (active and hidden_states.shape==(8,2560) and forward_batch.forward_mode.is_decode()):
  return original_prepare(self,positions,hidden_states,forward_batch)
 assert self.use_fused_qk_norm_mrope_cuda and hidden_states.dtype==torch.bfloat16
 assert positions.ndim==2 and positions.shape==(3,8) and positions.dtype==torch.int64
 assert forward_batch.spec_info is None and q3.get_exec().deterministic.rl_on_policy_target is None
 assert q3.get_parallel().attn_cp_size==1 and q3.get_parallel().attn_dcp_size==1
 assert not self.attn.is_cross_attention and self.attn.attn_type==q3.AttentionType.DECODER
 pool=q3.get_token_to_kv_pool();backend=q3.get_attn_backend()
 assert type(backend) is TRTLLMHAAttnBackend and type(pool) is MHATokenToKVPool and backend.token_to_kv_pool is pool and backend.data_type==torch.bfloat16
 cache_args=pool.get_bf16_hnd_write_args(self.attn,KVWriteLoc.for_batch(forward_batch));assert cache_args is not None
 w=self.qkv_proj.weight.detach()
 assert w.data_ptr()==self.qkv_proj.weight.data_ptr() and w.stride()==self.qkv_proj.weight.stride()
 assert w.shape==(6144,2560) and w.dtype==torch.bfloat16 and self.qkv_proj.bias is None and not hasattr(self.qkv_proj,'set_lora')
 assert self.q_norm.variance_epsilon==1e-6 and self.k_norm.variance_epsilon==1e-6
 assert self.q_norm.weight.dtype==self.k_norm.weight.dtype==torch.bfloat16
 self.rotary_emb._match_cos_sin_cache_dtype(hidden_states)
 qkv=torch.empty((8,6144),device=hidden_states.device,dtype=torch.bfloat16)
 kc,vc,slots=cache_args
 for param in [self.q_norm.weight,self.k_norm.weight]:
  detached=param.detach();assert detached.data_ptr()==param.data_ptr() and detached.stride()==param.stride()
 ep=(self.q_norm.weight.detach(),self.k_norm.weight.detach(),self.rotary_emb.cos_sin_cache,positions,self.rotary_emb.axis_map,kc.permute(0,2,1,3),vc.permute(0,2,1,3),slots)
 key=w.data_ptr()
 if key not in compiled:
  assert not torch.cuda.is_current_stream_capturing()
  compiled[key]=prototype.compile_epilogue(hidden_states,w.T,qkv,ep)
 compiled[key](hidden_states,w.T,qkv,ep)
 marker=(self.attn.layer_id,torch.cuda.is_current_stream_capturing())
 if marker not in prep_seen:
  prep_seen.add(marker);print('FUSED_PREP_DISPATCH',marker,flush=True)
  with (out/f'qkv-fused-pid{os.getpid()}.jsonl').open('a') as f: f.write(json.dumps(dict(layer=marker[0],capture=marker[1]))+'\n')
 q,k,v=qkv.split([4096,1024,1024],dim=-1)
 return q,k,v,False
q3.Qwen3Attention.forward_prepare_native=prepare

import json
import os
import pathlib

import torch
from flashinfer.autotuner import AutoTuner

from sglang.srt.layers.quantization import unquant
from sglang.srt.model_executor.model_runner import ModelRunner
from sglang.srt.model_executor.runner.decode_cuda_graph_runner import (
    DecodeCudaGraphRunner,
)

root = pathlib.Path(os.environ["QVL_LMHEAD_OUT"])
root.mkdir(parents=True, exist_ok=True)
seen = set()


def record(kind, **data):
    with (root / f"lmhead-proof-pid{os.getpid()}.jsonl").open("a") as f:
        f.write(json.dumps({"kind": kind, **data}) + "\n")


original = unquant._try_tuned_bf16_cublaslt


def dispatch(x, w, *a, **kw):
    y = original(x, w, *a, **kw)
    if y is not None:
        key = (tuple(x.shape), tuple(w.shape), torch.cuda.is_current_stream_capturing())
        if key not in seen:
            seen.add(key)
            record(
                "optimized_dispatch",
                input_shape=key[0],
                weight_shape=key[1],
                capture=key[2],
            )
    return y


unquant._try_tuned_bf16_cublaslt = dispatch
init = ModelRunner.init_cuda_graphs


def initialize(self, *a, **kw):
    head = getattr(self.model, "lm_head", None)
    w = getattr(head, "weight", None)
    record(
        "model_identity",
        model_type=type(self.model).__name__,
        model_module=type(self.model).__module__,
        tied_embedding=head
        is getattr(getattr(self.model, "model", None), "embed_tokens", None),
        quant_method=type(getattr(head, "quant_method", None)).__name__,
        weight_shape=list(w.shape) if w is not None else None,
        dtype=str(w.dtype) if w is not None else None,
        requires_grad=w.requires_grad if w is not None else None,
    )
    assert (
        type(self.model).__name__ == "Qwen3VLForConditionalGeneration"
        and type(self.model).__module__ == "sglang.srt.models.qwen3_vl"
    )
    assert head is getattr(getattr(self.model, "model", None), "embed_tokens", None)
    assert (
        type(getattr(head, "quant_method", None)).__name__
        == "UnquantizedEmbeddingMethod"
    )
    assert (
        tuple(w.shape) == (151936, 2560)
        and w.dtype == torch.bfloat16
        and not w.requires_grad
    )
    y = init(self, *a, **kw)
    cache = root / f"public-tuner-pid{os.getpid()}.json"
    AutoTuner.get().save_configs(str(cache))
    record(
        "startup",
        ready=sorted(unquant._CUBLASLT_BF16_READY),
        lmhead_enabled=getattr(
            getattr(self.model, "logits_processor", None),
            "_use_bf16_cublaslt_lm_head",
            False,
        ),
        cache=str(cache),
    )
    return y


ModelRunner.init_cuda_graphs = initialize
execute = DecodeCudaGraphRunner.execute
replayed = False


def replay(self, *a, **kw):
    global replayed
    y = execute(self, *a, **kw)
    if getattr(self, "bs", None) == 8 and not replayed:
        replayed = True
        record("graph8_replay")
    return y


DecodeCudaGraphRunner.execute = replay

from sglang.srt.managers.scheduler import Scheduler
epoch=0
flush=Scheduler.flush_cache
def traced_flush(self,*a,**kw):
 global epoch
 y=flush(self,*a,**kw);epoch+=1;record('flush',epoch=epoch,result=str(y));return y
Scheduler.flush_cache=traced_flush
forward=ModelRunner.forward
seen128=set()
def observed_forward(self,batch,*a,**kw):
 mode=batch.forward_mode.name
 if batch.input_ids.numel()==128 and (epoch,mode) not in seen128:
  seen128.add((epoch,mode));record('actual_M128_forward',epoch=epoch,mode=mode,batch_size=batch.batch_size)
 if batch.forward_mode.is_extend():
  record('extend_geometry',epoch=epoch,mode=mode,rows=batch.input_ids.numel(),batch_size=batch.batch_size,extend_lens=batch.extend_seq_lens_cpu,prefix_lens=batch.extend_prefix_lens_cpu)
 return forward(self,batch,*a,**kw)
ModelRunner.forward=observed_forward
