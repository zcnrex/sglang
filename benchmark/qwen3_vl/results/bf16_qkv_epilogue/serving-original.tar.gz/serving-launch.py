import os
import pathlib
import subprocess

r = pathlib.Path("/root/qvl/experiments/bf16-qkv-epilogue")
base = "/root/qvl/sglang-m16-down-production"
candidate = base
env = os.environ.copy()
env.update(
    TRITON_CACHE_DIR="/root/.cache/sglang/triton",
    TORCHINDUCTOR_CACHE_DIR="/root/.cache/sglang/inductor",
    CUDA_CACHE_PATH="/root/.cache/sglang/nv",
    FLASHINFER_WORKSPACE_BASE="/root/.cache/sglang",
    SGLANG_CUTE_AOT_CACHE_DIR="/root/.cache/sglang/cute_aot",
    QVL_RUN_ROOT=str(r / "serving"),
    QVL_CONTROL_SOURCE=base,
    QVL_CANDIDATE_SOURCE=candidate,
    QVL_CONTROL_MANIFEST=str(r / "control_expected.json"),
    QVL_CANDIDATE_MANIFEST=str(r / "candidate_expected.json"),
    QVL_GPUS="2,3",
    QVL_REQUESTS="80",
    QVL_WARMUP="64",
    QVL_CONCURRENCY="8",
)
cmd = ["/root/qvl/venv-sgl/bin/python", "-u", "/root/qvl/experiments/bf16-qkv-epilogue/serving.py"]
f = open(r / "serving-driver.log", "w")
p = subprocess.Popen(
    cmd, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True
)
print("serving", p.pid, flush=True)
