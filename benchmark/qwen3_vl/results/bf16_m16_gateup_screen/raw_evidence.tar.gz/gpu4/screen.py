import torch,flashinfer,glob,json,pathlib,sys,statistics,hashlib
from safetensors import safe_open
from flashinfer.autotuner import AutoTuner
from flashinfer.gemm import mm_bf16
root=pathlib.Path(__file__).parent;gpu=int(sys.argv[1]);torch.manual_seed(20261007);torch.backends.cuda.matmul.allow_tf32=False
model='/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17'
d={}
for p in glob.glob(model+'/*.safetensors'):
 with safe_open(p,framework='pt',device='cpu') as f:
  for key in f.keys():
   if any('.layers.'+str(l)+'.mlp.' in key for l in [0,17,35]) and any(key.endswith(t+'.weight') for t in ['gate_proj','up_proj']):d[key]=f.get_tensor(key).cuda()
ws=[torch.cat([d[f'model.language_model.layers.{l}.mlp.{t}_proj.weight'] for t in ['gate','up']]) for l in [0,17,35]]
assert all(w.shape==(19456,2560) and w.dtype==torch.bfloat16 for w in ws)
xs=[torch.randn(16,2560,device='cuda',dtype=torch.bfloat16) for _ in ws]
outs={v:[torch.empty(16,19456,device='cuda',dtype=torch.bfloat16) for _ in ws] for v in ['torch','lt']}
with flashinfer.autotune(tuning_buckets=(16,),round_up=False):mm_bf16(xs[0],ws[0].T,out=outs['lt'][0],backend='cublaslt')
AutoTuner.get().save_configs(str(root/'cache.json'))
def call(v):
 for x,w,o in zip(xs,ws,outs[v]):
  if v=='torch':torch.mm(x,w.T,out=o)
  else:mm_bf16(x,w.T,out=o,backend='cublaslt')
checks=[]
def check(tag):
 for i,(a,b,x,w) in enumerate(zip(outs['torch'],outs['lt'],xs,ws)):
  ref=x.float()@w.float().T
  row={'tag':tag,'layer':[0,17,35][i],'bitwise':torch.equal(a,b),'max_abs':(a.float()-b.float()).abs().max().item()}
  for v,y in [('torch',a),('lt',b)]:
   e=((y.float()-ref).square().mean()/ref.square().mean()).sqrt().item();row[v+'_nrms']=e;assert e<.005
  checks.append(row)
call('torch');call('lt');check('initial')
graphs={}
for v in ['torch','lt']:
 for _ in range(5):call(v)
 torch.cuda.synchronize();g=torch.cuda.CUDAGraph(keep_graph=True)
 with torch.cuda.graph(g):call(v)
 graphs[v]=g;g.debug_dump(str(root/(v+'.dot')))
for x in xs:x.normal_()
for g in graphs.values():g.replay()
torch.cuda.synchronize();check('changed_input_graph')
for g in graphs.values():
 for _ in range(5):g.replay()
torch.cuda.synchronize()
rounds=[]
for r in range(8):
 row={}
 for v in (['torch','lt'] if (r+gpu)%2==0 else ['lt','torch']):
  for _ in range(3):graphs[v].replay()
  a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True);a.record()
  for _ in range(80):graphs[v].replay()
  b.record();b.synchronize();row[v]=a.elapsed_time(b)*1000/240
 rounds.append(row);print(json.dumps(row),flush=True)
result=dict(gpu=gpu,m=16,n=19456,k=2560,weight_bytes=sum(w.numel()*w.element_size() for w in ws),layers=[0,17,35],checks=checks,rounds=rounds,median_us={v:statistics.median(r[v] for r in rounds) for v in ['torch','lt']},torch=torch.__version__,flashinfer=flashinfer.__version__)
(root/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['median_us']),flush=True)
