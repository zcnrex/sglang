import flashinfer
import torch,json,pathlib,glob,os,hashlib,statistics
from safetensors import safe_open
from sglang.kernels.ops.attention import qkv_norm_mrope as prototype
import masked
from flashinfer.gemm.kernels.dense_bf16_gemm_sm100_splitk import run_splitk_dense,SplitKTactic
from sglang.kernels.ops.attention.fused_qk_norm_mrope import fused_qk_norm_mrope
import sglang.srt.layers.quantization.unquant as uq
from flashinfer.gemm.kernels.dense_bf16_gemm_direct import prefer_direct_bf16_gemm_sm100
uq._prefer_direct=prefer_direct_bf16_gemm_sm100;uq._splitk_tactic=SplitKTactic;uq._run_splitk_dense=run_splitk_dense
assert uq._BF16_SPLITK_TUNED_TACTICS[(1,6144,2560)]==(128,8,2,6)
assert not uq._prefer_direct(1,6144,2560)
root=pathlib.Path(__file__).parent
torch.set_grad_enabled(False);torch.manual_seed(9107);torch.backends.cuda.matmul.allow_tf32=False
model='/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17'
d={}
for p in glob.glob(model+'/*.safetensors'):
 with safe_open(p,framework='pt',device='cpu') as f:
  for key in f.keys():
   if '.self_attn.' in key and any(key.endswith(x+'.weight') for x in ['q_proj','k_proj','v_proj','q_norm','k_norm']):d[key]=f.get_tensor(key).cuda().bfloat16()
phase=torch.arange(8400,device='cuda')[:,None].float()*torch.arange(1,65,device='cuda')[None,:].float()*.0001
rope=torch.cat([phase.cos(),phase.sin()],1).bfloat16();pos=torch.arange(8200,8201,device='cuda',dtype=torch.int64)[None,:].expand(3,-1).clone();axes=torch.tensor([0]*24+[1]*20+[2]*20,device='cuda',dtype=torch.int64)
# Each layer retains disjoint full-length HND caches. All variants write the same valid token slots.
slots=torch.arange(1,device='cuda',dtype=torch.int64)*8256+8200
slots[-1]=8200 if 1==1 else -1
pos[1].add_(37);pos[2].add_(71)
position_storage=torch.empty((3,128),device='cuda',dtype=torch.int64);position_storage[:,:1].copy_(pos);pos=position_storage[:,:1]
states=[]
for layer in range(36):
 prefix=f'model.language_model.layers.{layer}.self_attn.'
 w=torch.cat([d[prefix+x+'_proj.weight'] for x in ['q','k','v']]);qw=d[prefix+'q_norm.weight'];kw=d[prefix+'k_norm.weight']
 x=torch.randn(1,2560,device='cuda',dtype=torch.bfloat16);a=torch.empty(1,6144,device='cuda',dtype=torch.bfloat16);b=torch.empty_like(a)
 ka=torch.randn((258,8,32,128),device='cuda',dtype=torch.bfloat16);va=torch.randn_like(ka);kb=ka.clone();vb=va.clone()
 ep=(qw,kw,rope,pos,axes,kb,vb,slots)
 states.append((x,w,a,b,ka,va,kb,vb,ep))
d.clear();torch.cuda.empty_cache()
def f(x,wt,out,ep):
 qw,kw,rope,pos,axes,kc,vc,slots=ep
 result=prototype.qkv_norm_mrope(x,wt.T,qw,kw,rope,pos,axes,kc,vc,slots,out=out)
 assert result is out
f(states[0][0],states[0][1].T,states[0][3],states[0][-1])
print('compile_done',flush=True)
att_out={v:[torch.empty(1,32,128,device='cuda',dtype=torch.bfloat16) for _ in range(36)] for v in ['reference','candidate']}
workspace=torch.empty(512*1024**2,device='cuda',dtype=torch.uint8)
cb=torch.zeros(flashinfer.utils.get_trtllm_gen_multi_ctas_kv_counter_bytes(8192,32,flashinfer.utils.get_device_sm_count(torch.device('cuda:0'))),device='cuda',dtype=torch.uint8)
table=torch.arange(258,device='cuda',dtype=torch.int32).reshape(1,258)
lens=torch.full((1,),8201,device='cuda',dtype=torch.int32)

def run(i,v):
 x,w,a,b,ka,va,kb,vb,ep=states[i];qw,kw,rope,pos,axes,kb,vb,slots=ep
 if v=='reference':
  assert uq._bf16_splitk_gemm_out(x,w,None,a) is a
  fused_qk_norm_mrope(a[:,:4096],a[:,4096:5120],qw,kw,rope,pos,axes,1e-6,value=a[:,5120:],key_cache=ka.permute(0,2,1,3),value_cache=va.permute(0,2,1,3),slots=slots)
 else:f(x,w.T,b,ep)
 output=a if v=='reference' else b
 kv=(ka,va) if v=='reference' else (kb,vb)
 flashinfer.decode.trtllm_batch_decode_with_kv_cache(output[:,:4096].view(1,32,128),kv,workspace,table,lens,262144,bmm1_scale=128**-.5,bmm2_scale=1.,out=att_out[v][i],multi_ctas_kv_counter_buffer=cb)

checks=[]
def check(tag):
 torch.cuda.synchronize()
 for layer,(x,w,a,b,ka,va,kb,vb,ep) in enumerate(states):
  row=dict(tag=tag,layer=layer)
  for name,u,v in [('qkv',a,b),('keycache',ka,kb),('valuecache',va,vb),('attention',att_out['reference'][layer],att_out['candidate'][layer])]:
   eq=torch.equal(u,v);row[name+'_bitwise']=eq
   if not eq:
    e=u.float()-v.float();row[name+'_max_abs']=e.abs().max().item();row[name+'_nrms']=(e.square().mean()/u.float().square().mean()).sqrt().item()
   assert eq,row
  checks.append(row)
 print(tag,'36_layers_bitwise',flush=True)
for v in ['reference','candidate']:
 for i in range(36):run(i,v)
check('initial')
saved=prototype
prototype=masked
for i in range(36):run(i,'candidate')
check('masked_same_reference')
prototype=saved
graphs={}
for v in ['reference','candidate']:
 for _ in range(3):
  for i in range(36):run(i,v)
 torch.cuda.synchronize();g=torch.cuda.CUDAGraph(keep_graph=True)
 with torch.cuda.graph(g):
  for i in range(36):run(i,v)
 graphs[v]=g;g.debug_dump(str(root/(v+'.dot')))
for st in states:st[0].normal_()
pos.add_(13)
slots[-1]=-1
for g in graphs.values():g.replay()
check('changed_input_graph')
slots.copy_(torch.arange(1,device='cuda',dtype=torch.int64)*8256+8200)
for g in graphs.values():g.replay()
check('all_valid_slots_graph_before_timing')
for g in graphs.values():
 for _ in range(6):g.replay()
torch.cuda.synchronize()
def timing(v):
 a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True);a.record()
 for _ in range(100):graphs[v].replay()
 b.record();b.synchronize();return a.elapsed_time(b)*1000/(100*36)
rounds=[]
for r in range(8):
 row={v:timing(v) for v in (['reference','candidate'] if (r+int(os.environ.get('SCREEN_GPU','2')))%2==0 else ['candidate','reference'])};rounds.append(row);print(json.dumps(row),flush=True)
result=dict(positions_stride=pos.stride(),sequence='QKV+norm/rope/cache+TRTdecode',cache_inputs='seeded finite disjoint BF16, identical between arms',checks=checks,rounds=rounds,median_us={v:statistics.median(x[v] for x in rounds) for v in ['reference','candidate']},weight_bytes=sum(s[1].numel()*2 for s in states),cache_bytes_per_arm=sum(s[4].numel()*4 for s in states),pdl=True,states=36,tactic=[128,8,2,6],text_positions_only=False,negative_slot=True,caller_identity=True,prototype_sha256=hashlib.sha256(pathlib.Path(prototype.__file__).read_bytes()).hexdigest())
(root/'sequence.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['median_us']),flush=True)
