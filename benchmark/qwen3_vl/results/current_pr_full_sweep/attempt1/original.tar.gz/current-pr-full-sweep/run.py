import os,pathlib,json,hashlib,subprocess,sys,time,signal,shutil,urllib.request,threading
ROOT=pathlib.Path('/root/qvl/experiments/current-pr-full-sweep');SOURCE=pathlib.Path('/root/qvl/sglang-current-pr-full-sweep')
MODEL='/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17'
PYTHON='/root/qvl/venv-sgl/bin/python';BUCKETS=[1,2,4,8,12]+list(range(16,129,8))
POINTS=[(0,1,30),(1,4,40),(2,8,80),(3,16,80),(4,32,160),(5,64,320),(6,128,640),(7,128,640)]
def verify():
 expected=json.load(open(ROOT/'expected_source.json'));actual={}
 for p in SOURCE.rglob('*'):
  if p.is_symlink():actual[str(p.relative_to(SOURCE))]={'symlink':os.readlink(p)}
  elif p.is_file():actual[str(p.relative_to(SOURCE))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
 assert actual==expected,dict(extra=list(actual.keys()-expected.keys()),missing=list(expected.keys()-actual.keys()),changed=[k for k in actual.keys()&expected.keys() if actual[k]!=expected[k]])
 return dict(files=len(actual),manifest_sha256=hashlib.sha256((ROOT/'expected_source.json').read_bytes()).hexdigest(),verified_at=time.time())
def request(url,payload=None):
 req=urllib.request.Request(url,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=120) as r:
  raw=r.read().decode()
  try:return json.loads(raw)
  except json.JSONDecodeError:return raw
if len(sys.argv)==1:
 (ROOT/'source_verified.json').write_text(json.dumps(verify(),indent=2))
 foreign=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader']).decode();(ROOT/'foreign-pids-before.txt').write_text(foreign);assert not foreign.strip(),foreign
 stop=threading.Event()
 def telemetry():
  with (ROOT/'telemetry.jsonl').open('w') as f:
   while not stop.is_set():
    row=dict(time=time.time(),loadavg=pathlib.Path('/proc/loadavg').read_text(),cpu=pathlib.Path('/proc/stat').read_text().splitlines()[0],meminfo=pathlib.Path('/proc/meminfo').read_text(),processes=subprocess.check_output(['ps','-eo','pid,ppid,pcpu,rss,comm','--no-headers']).decode(),gpus=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,clocks.sm,clocks.mem,power.draw,temperature.gpu,utilization.gpu,utilization.memory,memory.used','--format=csv,noheader,nounits']).decode())
    f.write(json.dumps(row)+'\n');f.flush();stop.wait(1)
 t=threading.Thread(target=telemetry);t.start();workers=[]
 try:
  for gpu,c,n in POINTS:
   out=ROOT/f'gpu{gpu}-c{c}';out.mkdir();f=(out/'worker.log').open('w');p=subprocess.Popen([PYTHON,'-u',__file__,str(gpu),str(c),str(n)],stdout=f,stderr=subprocess.STDOUT,start_new_session=True);workers.append((p,out));print('WORKER',gpu,c,p.pid,flush=True)
  while not all((out/'ready').exists() for p,out in workers):
   failed=[str(out) for p,out in workers if p.poll() is not None];assert not failed,failed;time.sleep(2)
  infos=[json.load(open(out/'global_config.json')) for p,out in workers];assert all(x==infos[0] for x in infos),infos
  (ROOT/'global_config_verified.json').write_text(json.dumps(infos[0],indent=2));(ROOT/'start').touch()
  pending=list(workers)
  while pending:
   for p,out in list(pending):
    if p.poll() is not None:
     print('POINT_DONE',out.name,'exit',p.returncode,flush=True);pending.remove((p,out))
   time.sleep(2)
  assert all(p.returncode==0 for p,out in workers)
  (ROOT/'source_verified_after.json').write_text(json.dumps(verify(),indent=2));(ROOT/'complete').touch()
 finally:stop.set();t.join()
 raise SystemExit

gpu,c,n=map(int,sys.argv[1:]);out=ROOT/f'gpu{gpu}-c{c}';port=33000+gpu;url=f'http://127.0.0.1:{port}';cache=out/'isolated-cache';cache.mkdir()
(out/'source_verified.json').write_text(json.dumps(verify(),indent=2))
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(ROOT/'observer')+':'+str(SOURCE/'python'),PYTHONDONTWRITEBYTECODE='1',QVL_SWEEP_OUT=str(out),HF_HOME='/root/qvl/hf',SGLANG_USE_HND_KVCACHE='1',SGLANG_CACHE_DIR=str(cache),MAX_JOBS='8',TRITON_CACHE_DIR='/root/.cache/sglang/triton',TORCHINDUCTOR_CACHE_DIR='/root/.cache/sglang/inductor',CUDA_CACHE_PATH='/root/.cache/sglang/nv',FLASHINFER_WORKSPACE_BASE='/root/.cache/sglang',SGLANG_CUTE_AOT_CACHE_DIR='/root/.cache/sglang/cute_aot')
cmd=[PYTHON,'-m','sglang.launch_server','--model-path',MODEL,'--dtype','bfloat16','--kv-cache-dtype','bfloat16','--bf16-gemm-backend','cutedsl','--attention-backend','trtllm_mha','--page-size','32','--enable-mixed-chunk','--chunked-prefill-size','16384','--cuda-graph-backend-prefill','disabled','--cuda-graph-max-bs-decode','128','--cuda-graph-bs-decode']+list(map(str,BUCKETS))+['--max-total-tokens','1600000','--enforce-disable-flashinfer-allreduce-fusion','--host','127.0.0.1','--port',str(port)]
(out/'launch.json').write_text(json.dumps(dict(cmd=cmd,env={k:env[k] for k in env if k.startswith(('QVL_','SGLANG_','CUDA_','FLASHINFER_','TRITON_','TORCHINDUCTOR_')) or k in ['PYTHONPATH','PYTHONDONTWRITEBYTECODE','MAX_JOBS','HF_HOME']},gpu=gpu,concurrency=c,requests=n,warmup=max(64,c)),indent=2))
server=subprocess.Popen(cmd,env=env,stdout=(out/'server.log').open('w'),stderr=subprocess.STDOUT,start_new_session=True);(out/'server.pid').write_text(str(server.pid));print('SERVER',server.pid,flush=True)
try:
 while True:
  assert server.poll() is None,'Server terminal before readiness'
  try:request(url+'/v1/models');break
  except (OSError,ValueError):time.sleep(2)
 info=request(url+'/server_info');(out/'server_info.json').write_text(json.dumps(info,indent=2));assert info['max_total_num_tokens']==1600000
 keys=['dtype','kv_cache_dtype','attention_backend','page_size','chunked_prefill_size','enable_mixed_chunk','bf16_gemm_backend','cuda_graph_config','cuda_graph_bs_decode','cuda_graph_max_bs_decode','max_total_tokens','max_total_num_tokens','max_running_requests','max_prefill_tokens','mem_fraction_static','disable_overlap_schedule','speculative_algorithm','tp_size','pp_size','dp_size']
 config={k:info.get(k) for k in keys};(out/'global_config.json').write_text(json.dumps(config,indent=2))
 proof=[json.loads(z) for p in out.glob('observer-*.jsonl') for z in p.read_text().splitlines()];assert {x['layer'] for x in proof if x['kind']=='qkv_dispatch' and x['capture']}==set(range(36));startup=[x for x in proof if x['kind']=='startup'];assert len(startup)==1 and startup[0]['capture_bs']==BUCKETS,startup
 shutil.copytree(cache,out/'startup-cache');(out/'ready').touch()
 while not (ROOT/'start').exists():time.sleep(1)
 benv=env.copy();benv['PYTHONPATH']=str(SOURCE/'python');benv.pop('QVL_SWEEP_OUT',None)
 bench=['/root/qvl/venv-bench/bin/sgl-bench','serve','--backend','sglang-oai-chat','--base-url',url,'--model',MODEL,'--dataset-name','random','--random-range-ratio','1','--num-prompts',str(n),'--max-concurrency',str(c),'--warmup-requests',str(max(64,c)),'--flush-cache','--random-input-len','8192','--random-output-len','1024','--output-details','--output-file',str(out/'bench.jsonl')]
 (out/'bench-command.json').write_text(json.dumps(bench,indent=2));(out/'benchmark-start.json').write_text(json.dumps(dict(time=time.time())))
 subprocess.run(bench,env=benv,stdout=(out/'bench.log').open('w'),stderr=subprocess.STDOUT,check=True)
 (out/'benchmark-end.json').write_text(json.dumps(dict(time=time.time())))
 x=json.loads((out/'bench.jsonl').read_text().splitlines()[-1]);assert (x['completed'],x['total_input_tokens'],x['total_output_tokens'])==(n,n*8192,n*1024);assert len(x['ttfts'])==n
 request(url+'/flush_cache');summary={k:v for k,v in x.items() if k in ['duration','completed','total_input_tokens','total_output_tokens','output_throughput'] or 'ttft_ms' in k or 'tpot_ms' in k};(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
finally:
 if server.poll() is None:
  os.killpg(server.pid,signal.SIGTERM)
  try:server.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
 (out/'server-exit.json').write_text(json.dumps(dict(returncode=server.returncode,time=time.time())))
