import os,json,pathlib,time,collections
import torch
from flashinfer.autotuner import AutoTuner
from sglang.srt.models.qwen3 import Qwen3Attention
from sglang.srt.model_executor.model_runner import ModelRunner
from sglang.srt.managers.scheduler import Scheduler
from sglang.srt.layers.quantization import unquant
out=pathlib.Path(os.environ['QVL_SWEEP_OUT']);out.mkdir(parents=True,exist_ok=True)
def record(kind,**data):
 with (out/f'observer-{os.getpid()}.jsonl').open('a') as f:f.write(json.dumps(dict(time=time.time(),kind=kind,**data))+'\n')
prep=Qwen3Attention._try_qkv_norm_mrope;seen=set()
def observe(self,*args,**kwargs):
 result=prep(self,*args,**kwargs)
 if result is not None:
  key=(self.attn.layer_id,torch.cuda.is_current_stream_capturing())
  if key not in seen:seen.add(key);record('qkv_dispatch',layer=key[0],capture=key[1])
 return result
Qwen3Attention._try_qkv_norm_mrope=observe
init=ModelRunner.init_cuda_graphs
def initialize(self,*args,**kwargs):
 result=init(self,*args,**kwargs)
 path=out/f'public-tuner-{os.getpid()}.json';AutoTuner.get().save_configs(str(path))
 runner=self.decode_cuda_graph_runner
 record('startup',ready=sorted(unquant._CUBLASLT_BF16_READY),capture_bs=runner.capture_bs,graph_keys=[str(k) for k in runner.backend._graphs],cache=str(path))
 assert {layer for layer,capture in seen if capture}==set(range(36)),seen
 return result
ModelRunner.init_cuda_graphs=initialize
epoch=0;counts=collections.Counter();m128=collections.Counter()
forward=ModelRunner.forward
def observed_forward(self,batch,*args,**kwargs):
 rows=batch.input_ids.numel();mode=batch.forward_mode.name;counts[(mode,rows)]+=1
 if rows==128:m128[mode]+=1
 return forward(self,batch,*args,**kwargs)
ModelRunner.forward=observed_forward
flush=Scheduler.flush_cache
def observed_flush(self,*args,**kwargs):
 global epoch
 result=flush(self,*args,**kwargs)
 record('epoch_end',epoch=epoch,m128=dict(m128),forward_shapes=[dict(mode=k[0],rows=k[1],count=v) for k,v in sorted(counts.items())],flush_result=str(result))
 counts.clear();m128.clear();epoch+=1;record('epoch_start',epoch=epoch)
 return result
Scheduler.flush_cache=observed_flush
