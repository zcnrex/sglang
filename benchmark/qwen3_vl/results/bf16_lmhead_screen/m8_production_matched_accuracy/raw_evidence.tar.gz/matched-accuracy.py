import argparse
import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import time
import urllib.request

p = argparse.ArgumentParser()
p.add_argument("--source", required=True)
p.add_argument("--gpu", required=True)
p.add_argument("--variant", required=True)
p.add_argument("--extra", action="append", default=[])
a = p.parse_args()
r = pathlib.Path("/root/qvl/experiments/lmhead-m8-production-matched-accuracy") / a.variant
r.mkdir(parents=True, exist_ok=True)
model = "/root/qvl/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17"
port = 32100 + int(a.gpu)
url = f"http://127.0.0.1:{port}"
cache = r / "isolated-cache"
assert not cache.exists(), "Fresh per-run cache required"
cache.mkdir()
shutil.copytree("/root/qvl/experiments/lmhead-m8-production-accuracy/control/startup-cache",cache,dirs_exist_ok=True)
env = dict(
    os.environ,
    SGLANG_CACHE_DIR=str(cache),
    CUDA_VISIBLE_DEVICES=a.gpu,
    PYTHONPATH="/root/qvl/experiments/lmhead-m8-production-matched-observer:"
    + a.source
    + "/python",
    QVL_LMHEAD_OUT=str(r),
    HF_HOME="/root/qvl/hf",
    SGLANG_USE_HND_KVCACHE="1",
    QVL_FA4_EVIDENCE_DIR=str(r),
    QVL_FA4_REPORT=str(r / "fa4-coverage.json"),
    QVL_PACK_REPORT_DIR=str(r),
    TRITON_CACHE_DIR="/root/.cache/sglang/triton",
    TORCHINDUCTOR_CACHE_DIR="/root/.cache/sglang/inductor",
    CUDA_CACHE_PATH="/root/.cache/sglang/nv",
    FLASHINFER_WORKSPACE_BASE="/root/.cache/sglang",
    SGLANG_CUTE_AOT_CACHE_DIR="/root/.cache/sglang/cute_aot",
    MAX_JOBS="8",
)
cmd = [
    "/root/qvl/venv-sgl/bin/python",
    "-m",
    "sglang.launch_server",
    "--model-path",
    model,
    "--bf16-gemm-backend",
    "cutedsl",
    "--dtype",
    "bfloat16",
    "--kv-cache-dtype",
    "bfloat16",
    "--attention-backend",
    "trtllm_mha",
    "--page-size",
    "32",
    "--enable-mixed-chunk",
    "--chunked-prefill-size",
    "16384",
    "--cuda-graph-backend-prefill",
    "disabled",
    "--enforce-disable-flashinfer-allreduce-fusion",
    "--host",
    "127.0.0.1",
    "--port",
    str(port),
] + a.extra
(r / "command.json").write_text(
    json.dumps(
        {
            "server": cmd,
            "env": {
                k: env[k]
                for k in [
                    "CUDA_VISIBLE_DEVICES",
                    "PYTHONPATH",
                    "HF_HOME",
                    "SGLANG_USE_HND_KVCACHE",
                    "QVL_FA4_EVIDENCE_DIR",
                    "SGLANG_CACHE_DIR",
                ]
            },
            "source": a.source,
            "cache_policy": "fresh isolated per worker; no prior tuning cache loaded",
        },
        indent=2,
    )
)
source = pathlib.Path(a.source)
expected = json.load(open(os.environ["QVL_EXPECTED_MANIFEST"]))
actual = {
    str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (source / "python").rglob("*.py")
}
assert actual == expected
(r / "source-manifest.json").write_text(json.dumps(actual, indent=2))
f = (r / "server.log").open("w")
server = subprocess.Popen(
    cmd, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True
)
(r / "server.pid").write_text(str(server.pid))
try:
    for _ in range(600):
        if server.poll() is not None:
            raise RuntimeError("Server exited")
        try:
            with urllib.request.urlopen(url + "/v1/models", timeout=2):
                break
        except OSError:
            time.sleep(2)
    else:
        raise RuntimeError("Readiness timeout")
    shutil.copytree(cache, r / "startup-cache")
    proof = [
        json.loads(line)
        for p in r.glob("lmhead-proof-pid*.jsonl")
        for line in p.read_text().splitlines()
    ]
    if a.variant == "candidate":
        assert any(
            x["kind"] == "startup"
            and x["lmhead_enabled"]
            and any(z[1:] == [8, 151936, 2560] for z in x["ready"])
            for x in proof
        ), proof
        assert any(
            x["kind"] == "optimized_dispatch"
            and x["input_shape"] == [8, 2560]
            and x["weight_shape"] == [151936, 2560]
            and x["capture"]
            for x in proof
        ), proof
    bench = [
        "/root/qvl/venv-sgl/bin/python",
        "/root/qvl/sglang-current-profile/benchmark/qwen3_vl/eval_gsm8k.py",
        "--base-url",
        url,
        "--output",
        str(r / "results"),
        "--model",
        model,
        "--num-examples",
        "1314",
        "--num-threads",
        "8",
        "--max-tokens",
        "2048",
    ]
    (r / "eval-command.json").write_text(json.dumps(bench, indent=2))
    with (r / "eval.log").open("w") as log:
        subprocess.run(bench, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
finally:
    if server.poll() is None:
        os.killpg(server.pid, signal.SIGTERM)
        try:
            server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(server.pid, signal.SIGKILL)
            server.wait()
    f.close()
