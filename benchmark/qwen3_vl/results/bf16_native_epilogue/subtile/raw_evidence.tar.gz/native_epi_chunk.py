from typing import Tuple, Union
import cutlass
from cutlass import Float32
import cutlass.cute.math as cmath
import cutlass.cute as cute
from cutlass.cutlass_dsl import Int32, Boolean, Constexpr, const_expr
import cutlass.pipeline as pipeline
from cutlass.utils.static_persistent_tile_scheduler import StaticPersistentTileScheduler
from cutlass.utils.blackwell_helpers import get_tmem_load_op, get_smem_store_op
from cutlass.cute.nvgpu import cpasync, tcgen05
from cutlass.cute.nvgpu.common import CacheEvictionPriority

from cutlass.utils.gemm.sm100 import transform_partitioned_tensor_layout, epilogue_tmem_copy_and_partition
@cute.jit
def epilogue(
    gemm_kernel,
    epi_tidx: Int32,
    tCtAcc_base: cute.Tensor,
    tCgC_base: cute.Tensor,
    epi_tile: cute.Tile,
    epilogue_op: Constexpr,
    mma_tile_coord_mnl: Tuple[Int32, Int32, Int32],
    acc_consumer_state: pipeline.PipelineState,
    acc_pipeline: pipeline.PipelineAsync,
    tCcC_base: cute.Tensor = None,
    mC_mnl: cute.Tensor = None,
    overlapping_accum: Constexpr = False,
) -> pipeline.PipelineState:
    """
    Epilogue function that stores accumulator results directly to global memory.
    Used when TMA store is not enabled.

    :param gemm_kernel: The kernel instance
    :type gemm_kernel: Any
    :param epi_tidx: Thread index in epilogue warp groups
    :type epi_tidx: Int32
    :param tCtAcc_base: Base accumulator tensor in tensor memory
    :type tCtAcc_base: cute.Tensor
    :param tCgC_base: The global memory tensor C to be copied and partitioned
    :type tCgC_base: cute.Tensor
    :param epi_tile: Epilogue tile configuration
    :type epi_tile: cute.Tile
    :param epilogue_op: Optional elementwise operation to apply
    :type epilogue_op: Constexpr
    :param mma_tile_coord_mnl: MMA tile coordinates (M, N, L)
    :type mma_tile_coord_mnl: Tuple[Int32, Int32, Int32]
    :param acc_consumer_state: Accumulator consumer pipeline state
    :type acc_consumer_state: pipeline.PipelineState
    :param acc_pipeline: Accumulator pipeline for async operations
    :type acc_pipeline: pipeline.PipelineAsync
    :param tCcC_base: Identity/coordinate tensor C
    :type tCcC_base: cute.Tensor
    :param mC_mnl: Global memory tensor C (full tensor for predicate computation)
    :type mC_mnl: cute.Tensor
    :param overlapping_accum: Whether to use overlapping accumulator
    :type overlapping_accum: Constexpr
    """

    # Layout transformation for tCgC_base
    # ((MMA_ATOM_M, MMA_ATOM_N), MMA_M, MMA_N, TILE_M, TILE_N, TILE_K)
    # -> ((MMA_ATOM_M, MMA_M), (MMA_ATOM_N, MMA_N), TILE_M, TILE_N, TILE_K)
    tCgC = transform_partitioned_tensor_layout(tCgC_base)

    # Layout transformation for tCtAcc_base
    # ((MMA_ATOM_M, MMA_ATOM_N), MMA_M, MMA_N, STAGE)
    # -> ((MMA_ATOM_M, MMA_M), (MMA_ATOM_N, MMA_N), STAGE)
    tCtAcc = transform_partitioned_tensor_layout(tCtAcc_base)

    #
    # Partition for epilogue
    #
    (
        tiled_copy_t2r,
        tTR_tAcc_base,
        tTR_rAcc,
    ) = epilogue_tmem_copy_and_partition(
        gemm_kernel, epi_tidx, tCtAcc, tCgC, epi_tile, gemm_kernel.use_2cta_instrs
    )

    gC_epi = cute.flat_divide(tCgC, epi_tile)
    # (T2R, T2R_M, T2R_N, EPI_M, EPI_N, RestM, RestN, RestL)
    thr_copy_t2r = tiled_copy_t2r.get_slice(epi_tidx)
    tTR_gC_partitioned = thr_copy_t2r.partition_D(gC_epi)
    # (T2R, T2R_M, T2R_N)
    tTR_rC = cute.make_rmem_tensor(
        tTR_gC_partitioned[(None, None, None, 0, 0, 0, 0, 0)].shape, gemm_kernel.c_dtype
    )

    mclD = cute.max_common_layout(
        tTR_rC.layout, tTR_gC_partitioned[(None, None, None, 0, 0, 0, 0, 0)].layout
    )
    num_bits_per_copy = min(
        tTR_gC_partitioned.iterator.alignment * 8,
        cute.size(mclD) * gemm_kernel.c_dtype.width,
        256,
    )

    simt_atom = cute.make_copy_atom(
        cute.nvgpu.CopyUniversalOp(),
        gemm_kernel.c_dtype,
        num_bits_per_copy=num_bits_per_copy,
        l1c_evict_priority=CacheEvictionPriority.NO_ALLOCATE,
    )
    use_predication = tCcC_base is not None and mC_mnl is not None

    if const_expr(use_predication):
        # Layout transformation for tCcC_base
        # ((MMA_ATOM_M, MMA_ATOM_N), MMA_M, MMA_N, TILE_M, TILE_N, TILE_K)
        # -> ((MMA_ATOM_M, MMA_M), (MMA_ATOM_N, MMA_N), TILE_M, TILE_N, TILE_K)
        tCcC = transform_partitioned_tensor_layout(tCcC_base)
        cC_epi = cute.flat_divide(tCcC, epi_tile)
        tTR_cC_partitioned = thr_copy_t2r.partition_D(cC_epi)

    # (T2R, T2R_M, T2R_N, EPI_M, EPI_N)
    tTR_gC = tTR_gC_partitioned[
        (
            None,
            None,
            None,
            None,
            None,
            *mma_tile_coord_mnl,
        )
    ]

    if const_expr(use_predication):
        # (T2R, T2R_M, T2R_N, EPI_M, EPI_N)
        tTR_cC = tTR_cC_partitioned[
            (
                None,
                None,
                None,
                None,
                None,
                *mma_tile_coord_mnl,
            )
        ]
        tTR_cC = cute.group_modes(tTR_cC, 3, cute.rank(tTR_cC))

    # Get accumulator stage index
    if const_expr(overlapping_accum):
        acc_stage_index = acc_consumer_state.phase
        reverse_subtile = acc_stage_index == 0
    else:
        acc_stage_index = acc_consumer_state.index

    # Set tensor memory buffer for current tile
    # (T2R, T2R_M, T2R_N, EPI_M, EPI_M)
    tTR_tAcc = tTR_tAcc_base[(None, None, None, None, None, acc_stage_index)]

    #
    # Wait for accumulator buffer full
    #
    acc_pipeline.consumer_wait(acc_consumer_state)

    tTR_tAcc = cute.group_modes(tTR_tAcc, 3, cute.rank(tTR_tAcc))
    tTR_gC = cute.group_modes(tTR_gC, 3, cute.rank(tTR_gC))
    #
    # Store accumulator to global memory in subtiles
    #
    subtile_cnt = cute.size(tTR_tAcc.shape, mode=[3])
    for subtile_idx in range(subtile_cnt):
        # Compute the actual subtile index
        real_subtile_idx = subtile_idx
        if const_expr(overlapping_accum):
            if reverse_subtile:
                real_subtile_idx = subtile_cnt - 1 - subtile_idx
        #
        # Get the destination and coordinate slices for this subtile
        #
        tTR_gC_subtile = tTR_gC[(None, None, None, real_subtile_idx)]
        #
        # Load accumulator from tensor memory buffer to register
        #
        tTR_tAcc_mn = tTR_tAcc[(None, None, None, real_subtile_idx)]
        cute.copy(tiled_copy_t2r, tTR_tAcc_mn, tTR_rAcc)

        #
        # Async arrive accumulator buffer empty
        #
        if const_expr(overlapping_accum):
            # Early release when overlapping: release after processing the
            # overlapping region (SF columns) so they can be reused
            if subtile_idx == gemm_kernel.iter_acc_early_release_in_epilogue:
                cute.arch.fence_view_async_tmem_load()
                with cute.arch.elect_one():
                    acc_pipeline.consumer_release(acc_consumer_state)
                acc_consumer_state.advance()
        else:
            # Release early for perf at the last subtile
            if subtile_idx == subtile_cnt - 1:
                with cute.arch.elect_one():
                    acc_pipeline.consumer_release(acc_consumer_state)
                acc_consumer_state.advance()

        # Round before activation, matching materialized BF16 GEMM boundary.
        acc_vec = tTR_rAcc.load().to(gemm_kernel.c_dtype)
        tTR_rC.store(acc_vec)
        offset_bytes = tTR_gC_subtile.iterator.toint() - mC_mnl.iterator.toint()
        vector_store = cute.make_copy_atom(cute.nvgpu.CopyUniversalOp(), gemm_kernel.c_dtype, num_bits_per_copy=128)
        for chunk in cutlass.range_constexpr(cute.size(tTR_rC) // 16):
            activated_registers = cute.make_rmem_tensor(cute.make_layout(8), gemm_kernel.c_dtype)
            for jj in cutlass.range_constexpr(8):
                j = chunk * 8 + jj
                gate = Float32(tTR_rC[2*j])
                up = Float32(tTR_rC[2*j+1])
                activated = (gate / (1.0 + cmath.exp(-gate, fastmath=True))) * up
                activated_registers[jj] = activated.to(gemm_kernel.c_dtype)
            paired = cute.make_tensor(mC_mnl.iterator + cute.assume(offset_bytes // 4 + chunk * 8, divby=8), cute.make_layout(8))
            if const_expr(use_predication):
                coords = tTR_cC[(None,None,None,real_subtile_idx)]
                if cute.elem_less(coords[0],mC_mnl.shape):
                    cute.copy(vector_store, activated_registers, paired)
            else:
                cute.copy(vector_store, activated_registers, paired)

    return acc_consumer_state

