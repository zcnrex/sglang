import os,pathlib,json,hashlib,importlib
import numpy as np
import torch
import sglang.benchmark.one_batch as b
from flashinfer.autotuner import AutoTuner
out=pathlib.Path(os.environ['QVL_MODEL_OUT']);out.mkdir(parents=True,exist_ok=True)
source=pathlib.Path(os.environ['QVL_SOURCE'])
actual={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'python').rglob('*.py')}
expected=json.load(open(os.environ['QVL_EXPECTED_MANIFEST']));assert actual==expected
(out/'source-manifest.json').write_text(json.dumps(actual,indent=2))
seen=set();report={'source':str(source),'source_files':len(actual)};saved={}
if os.environ['QVL_VARIANT']=='candidate':
 import sglang.srt.models.qwen3 as q3
 original_prepare=q3.Qwen3Attention._try_qkv_norm_mrope
 def observe(self,*args,**kwargs):
  result=original_prepare(self,*args,**kwargs)
  if result is not None:
   marker=(self.attn.layer_id,torch.cuda.is_current_stream_capturing())
   if marker not in seen: seen.add(marker);print('INTEGRATED_DISPATCH',marker,flush=True)
  return result
 q3.Qwen3Attention._try_qkv_norm_mrope=observe
original=b.load_model
@torch.no_grad()
def load(*args,**kwargs):
 wrapper,tok=original(*args,**kwargs)
 dr=wrapper.torch_runner.decode_cuda_graph_runner
 report['graph_keys']=[str(k) for k in dr.backend._graphs];report['dispatch']=sorted(seen)
 if os.environ['QVL_VARIANT']=='candidate': assert {i for i,c in seen if c}==set(range(36)),seen
 AutoTuner.get().save_configs(str(out/'cache.json'))
 for seed in [123,124]:
  wrapper.clear();data=np.random.default_rng(seed).integers(0,10000,(8,8192),dtype=np.int32)
  reqs=b.prepare_synthetic_inputs_for_latency_test(8,8192,data.tolist())
  ids,logits,batch=wrapper.extend(reqs);saved[f'{seed}_prefill']=logits.cpu();seq=[ids.cpu()]
  for step in range(15):
   ids,logits=wrapper.decode(ids,batch);seq.append(ids.cpu())
   if step in [0,14]:saved[f'{seed}_decode{step}']=logits.cpu()
  saved[f'{seed}_greedy']=torch.stack(seq)
  print('MODEL_SEED_COMPLETE',seed,flush=True)
 snapshots={n:v.clone() for n,v in vars(dr.buffers).items() if isinstance(v,torch.Tensor)}
 graph=next(g for k,g in dr.backend._graphs.items() if k.size==8)
 for _ in range(8):graph.replay()
 torch.cuda.synchronize()
 report['unchanged_input_buffers']={n:torch.equal(v,getattr(dr.buffers,n)) for n,v in snapshots.items()}
 assert all(report['unchanged_input_buffers'].values()),report
 torch.save(saved,out/'outputs.pt');(out/'report.json').write_text(json.dumps(report,indent=2))
 raise SystemExit(0)
b.load_model=load
np.random.seed(123);torch.manual_seed(123);b.cli_main()
