# BF16 QK normalization and rotary standalone protocol

Compare the existing CUDA implementation from immutable source d7b4556d6b with the adapted operator in the existing Triton module. Use GPU 7 only; production files are not modified by this harness.

The cases cover batches 1, 2, 4, 8, 16, 32, 64 and 128, with 36 disjoint layer states and actual checkpoint Q/K normalization weights. Q/K/V use BF16 with packed row stride 6144. Both contiguous and interleaved multimodal axis maps use distinct position rows and row stride 128. Cache variants use physical HND page size 32, disjoint buffers for each arm and layer, and logical cache views. Initial writes use valid slots. Changed-input graph validation changes inputs and positions and marks the final slot negative. Valid slots are restored for timing.

Bitwise equality is required for Q/K/V and the complete K/V cache buffers before timing. Layers 34 and 35 add wide dynamic-range and sparse large-lane normalization inputs. A numerical failure stops the run and records the exact case; tolerances are not relaxed.

Latency uses CUDA events around retained graphs containing 36 operator calls. Eight rounds reverse arm order, with 100 replays per arm per round. Inputs/caches reset outside timing; in-place normalization/rotation evolves the Q/K contents during repeated graph replay. Results are operator-only latency, not model or serving gains. Dependent GEMM/attention interactions require the later model gate.
