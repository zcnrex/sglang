import runpy
from sglang.srt.models import qwen3
original=qwen3.fused_qk_norm_mrope
announced=False
def observed(*args,**kwargs):
 global announced
 if kwargs.get('value') is not None and not announced:
  print('VALIDATION: production fused cache write selected',flush=True);announced=True
 return original(*args,**kwargs)
qwen3.fused_qk_norm_mrope=observed
runpy.run_module('sglang.benchmark.one_batch',run_name='__main__')
