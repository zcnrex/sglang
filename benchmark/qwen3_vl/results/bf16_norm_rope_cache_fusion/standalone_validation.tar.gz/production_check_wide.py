import torch,json,itertools
from pathlib import Path
from sglang.kernels.jit.utils import load_jit
from sglang.kernels.ops.attention.fused_qk_norm_mrope import fused_qk_norm_mrope
from sglang.kernels.ops.kvcache.cache_ops import launch_reshape_and_cache_flash
from triton.testing import do_bench_cudagraph
for layout,n,interleaved,(qh,kh) in itertools.product(('HND',),(1,8,128),(False,True),((32,8),(16,4),(8,2),(4,1))):
 torch.manual_seed(42)
 x=torch.randn(n,(qh+2*kh)*128,device='cuda',dtype=torch.bfloat16);original=x.clone();q,k,v=x.split([qh*128,kh*128,kh*128],dim=-1)
 qw=torch.randn(128,device='cuda',dtype=torch.bfloat16);kw=torch.randn_like(qw)
 phase=torch.randn(16384,64,device='cuda');cache=torch.cat([phase.cos(),phase.sin()],1).bfloat16();positions=torch.randint(0,16384,(3,n),device='cuda')
 axis=[0]*24+[1]*20+[2]*20
 if interleaved:
  axis=[0]*64
  for a in (1,2):
   for d in range(a,60,3):axis[d]=a
 axis=torch.tensor(axis,device='cuda',dtype=torch.int64)
 shape=(256,32,kh,128) if layout=='NHD' else (256,kh,32,128)
 kc=torch.zeros(shape,device='cuda',dtype=torch.bfloat16);vc=torch.zeros_like(kc)
 if layout=='HND':kc=kc.permute(0,2,1,3);vc=vc.permute(0,2,1,3)
 slots=torch.randperm(256*32,device='cuda')[:n].long()
 if n>1:slots[::7]=-1
 def old():
  fused_qk_norm_mrope(q,k,qw,kw,cache,positions,axis,1e-6)
  launch_reshape_and_cache_flash(k.view(n,kh,128),v.view(n,kh,128),kc,vc,slots)
 def new():fused_qk_norm_mrope(q,k,qw,kw,cache,positions,axis,1e-6,value=v,key_cache=kc,value_cache=vc,slots=slots)
 old();expected=x.clone();expected_k=kc.clone();expected_v=vc.clone()
 x.copy_(original);kc.zero_();vc.zero_();new()
 valid=torch.equal(x,expected) and torch.equal(kc,expected_k) and torch.equal(vc,expected_v)
 assert valid,(layout,n,interleaved,(x-expected).abs().max().item(),(kc-expected_k).abs().max().item())
 print(json.dumps(dict(layout=layout,n=n,q_heads=qh,kv_heads=kh,interleaved=interleaved,bitwise=valid)),flush=True)
