import argparse,json,os,pathlib,signal,subprocess,time,urllib.request,socket
ROOT=pathlib.Path('/root/qvl')
MODEL=str(ROOT/'hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17')
p=argparse.ArgumentParser();p.add_argument('variant',choices=['reference','combined']);p.add_argument('--run',action='store_true');p.add_argument('--gpu',type=int);p.add_argument('--round',default='first');args=p.parse_args()
gpu=args.gpu if args.gpu is not None else (0 if args.variant=='reference' else 1);port=32000+gpu
source=ROOT/('sglang-cache-integration' if args.variant=='combined' else 'sglang-perf')
out=ROOT/'experiments/cache-fusion-serving'/args.round/(args.variant+'-gpu'+str(gpu))
command=[str(ROOT/'venv-sgl/bin/python'),'-m','sglang.launch_server','--model-path',MODEL,'--dtype','bfloat16','--kv-cache-dtype','auto','--attention-backend','trtllm_mha','--page-size','32','--chunked-prefill-size','16384','--cuda-graph-backend-prefill','disabled','--enforce-disable-flashinfer-allreduce-fusion','--host','127.0.0.1','--port',str(port)]
command+=['--enable-mixed-chunk','--cuda-graph-config','{"decode":{"max_bs":128}}']
env=dict(os.environ,HF_HOME=str(ROOT/'hf'),PYTHONPATH=str(source/'python'),CUDA_VISIBLE_DEVICES=str(gpu),SGLANG_USE_HND_KVCACHE='1',QVL_CACHE_FUSION='0',QVL_RUN_MODULE='sglang.launch_server')
print(json.dumps({'command':command,'source':str(source),'gpu':gpu,'hnd':env['SGLANG_USE_HND_KVCACHE'],'run':args.run}),flush=True)
if not args.run:raise SystemExit
with socket.socket() as s:
 if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('Port occupied')
out.mkdir(exist_ok=False,parents=True)
meta={'model_snapshot':'ebb281ec70b05090aa6165b016eac8ec08e71b17','command':command,'gpu':gpu,'source':str(source),'environment':{k:env[k] for k in ('HF_HOME','PYTHONPATH','CUDA_VISIBLE_DEVICES','SGLANG_USE_HND_KVCACHE','QVL_CACHE_FUSION','QVL_RUN_MODULE')},'benchmark_commit':'a9da34ad1f997ca05878d858d3d01970e4a49af9','points':[(1,3,1),(4,40,64),(8,80,64)]}
(out/'metadata.json').write_text(json.dumps(meta,indent=2))
for name,cmd in {'git_head':['git','-C',str(source),'rev-parse','HEAD'],'git_status':['git','-C',str(source),'status','--short'],'git_diff':['git','-C',str(source),'diff'],'gpu_before':['nvidia-smi'],'serving_packages':[str(ROOT/'venv-sgl/bin/python'),'-c','import importlib.metadata as m; print(chr(10).join(sorted(d.metadata["Name"]+"=="+d.version for d in m.distributions())))'],'benchmark_packages':[str(ROOT/'venv-bench/bin/python'),'-c','import importlib.metadata as m; print(chr(10).join(sorted(d.metadata["Name"]+"=="+d.version for d in m.distributions())))']}.items():
 with (out/f'{name}.txt').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
serverlog=(out/'server.log').open('w');server=subprocess.Popen(command,env=env,stdout=serverlog,stderr=subprocess.STDOUT,start_new_session=True);(out/'server.pid').write_text(str(server.pid));pmon=None
try:
 for _ in range(450):
  if server.poll() is not None:raise RuntimeError('Server exited')
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=2):break
  except OSError:time.sleep(2)
 else:raise RuntimeError('Readiness timeout')
 with urllib.request.urlopen(f'http://127.0.0.1:{port}/server_info') as r:(out/'server_info.json').write_bytes(r.read())
 pmonlog=(out/'pmon.log').open('w');pmon=subprocess.Popen(['nvidia-smi','pmon','-i',str(gpu),'-s','u','-d','1'],stdout=pmonlog,stderr=subprocess.STDOUT)
 import hashlib,shutil
 for fname in ('production.patch',):
  source_file=ROOT/'experiments/qvl-cache-fusion'/fname
  shutil.copyfile(source_file,out/fname)
  (out/(fname+'.sha256')).write_text(hashlib.sha256(source_file.read_bytes()).hexdigest())
 greedy=[]
 for prompt in ('The capital of France is','Compute 19 + 23. Answer:','A bird can'):
  payload={'text':prompt,'sampling_params':{'temperature':0,'max_new_tokens':32},'return_logprob':True,'top_logprobs_num':5}
  request=urllib.request.Request(f'http://127.0.0.1:{port}/generate',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(request,timeout=120) as response:greedy.append(json.load(response))
 (out/'greedy.json').write_text(json.dumps(greedy,indent=2))
 evaluation=[str(ROOT/'venv-sgl/bin/python'),str(source/'benchmark/qwen3_vl/eval_gsm8k.py'),'--base-url',f'http://127.0.0.1:{port}','--model',MODEL,'--output',str(out/'gsm8k'),'--num-threads','32']
 with (out/'evaluation.log').open('w') as log:subprocess.run(evaluation,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print((out/'gsm8k/metrics.json').read_text(),flush=True)
finally:
 if pmon is not None:pmon.terminate();pmon.wait(timeout=10)
 if server.poll() is None:
  os.killpg(server.pid,signal.SIGTERM)
  try:server.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
 serverlog.close()
 with (out/'gpu_after.txt').open('w') as f:subprocess.run(['nvidia-smi'],stdout=f,check=False)
