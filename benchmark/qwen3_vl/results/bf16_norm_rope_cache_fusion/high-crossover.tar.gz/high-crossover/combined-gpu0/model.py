import os,runpy
if os.environ.get('QVL_CACHE_FUSION')=='1':
 import torch
 from pathlib import Path
 from sglang.kernels.jit.utils import load_jit,cache_once
 from sglang.srt.models.qwen3 import Qwen3Attention
 from sglang.srt.model_executor.forward_context import get_token_to_kv_pool
 from sglang.srt.mem_cache.memory_pool import unwrap_write_loc
 @cache_once
 def module():
  return load_jit('qvl_norm_rope_cache',cuda_files=[str(Path(__file__).with_name('fused.cuh'))],cuda_wrappers=[('run','FusedQKNormMRoPE<true>::run')])
 old_forward=Qwen3Attention.forward
 announced=False
 def forward(self,positions,hidden_states,forward_batch):
  global announced
  if not (self.use_fused_qk_norm_mrope_cuda and forward_batch.forward_mode.is_decode() and 0<hidden_states.shape[0]<=128):
   return old_forward(self,positions,hidden_states,forward_batch)
  qkv,_=self.qkv_proj(hidden_states)
  q,k,v=qkv.split([self.q_size,self.kv_size,self.kv_size],dim=-1)
  pool=get_token_to_kv_pool();kc,vc=pool.get_kv_buffer(self.attn.layer_id)
  assert q.dtype==kc.dtype==vc.dtype==torch.bfloat16
  assert pool.use_hnd
  kc=kc.permute(0,2,1,3);vc=vc.permute(0,2,1,3)
  loc,_,_=unwrap_write_loc(forward_batch.out_cache_loc)
  self.rotary_emb._match_cos_sin_cache_dtype(q)
  module().run(q,k,v,self.q_norm.weight,self.k_norm.weight,self.rotary_emb.cos_sin_cache,positions,self.rotary_emb.axis_map,kc,vc,loc,self.q_norm.variance_epsilon)
  if not announced:
   print('EXPERIMENT: fused QK norm/MRoPE and cache write active',flush=True);announced=True
  attn=self.attn(q,None,None,forward_batch,save_kv_cache=False)
  return self.o_proj(attn)[0]
 Qwen3Attention.forward=forward
if os.environ.get('QVL_GRAPH_TIMING')=='1':
 import atexit,json,statistics,torch
 from collections import defaultdict
 from sglang.srt.model_executor.runner_backend.full_cuda_graph_backend import FullCudaGraphBackend
 events=defaultdict(list)
 old_replay=FullCudaGraphBackend.replay
 def timed_replay(self,shape_key,static_forward_batch,**kwargs):
  a=torch.cuda.Event(enable_timing=True);b=torch.cuda.Event(enable_timing=True)
  a.record();result=old_replay(self,shape_key,static_forward_batch,**kwargs);b.record()
  events[static_forward_batch.batch_size].append((a,b))
  return result
 FullCudaGraphBackend.replay=timed_replay
 def report():
  torch.cuda.synchronize()
  for bs,values in sorted(events.items()):
   us=[a.elapsed_time(b)*1000 for a,b in values[5:]]
   if us:print(json.dumps(dict(stage='graph_timing',batch_size=bs,median_us=statistics.median(us),count=len(us))),flush=True)
 atexit.register(report)
if __name__=='__main__':runpy.run_module(os.environ.get('QVL_RUN_MODULE','sglang.benchmark.one_batch'),run_name='__main__')
